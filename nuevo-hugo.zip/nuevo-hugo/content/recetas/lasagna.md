---
title: "Lasaña Casera"
date: 2025-10-29
draft: false
---

Receta fácil para preparar una deliciosa Lasaña casera con masa crujiente.
---
title: "Lasaña Boloñesa Casera"
date: 2025-10-29
draft: false
---

# 🧀 Lasaña Boloñesa
La **lasaña** es uno de los platos más *famosos* de Italia, perfecta para compartir en familia.

## Ingredientes principales
- **Láminas de pasta**
- *Carne molida de res*
- **Salsa bechamel**
- *Queso mozzarella y parmesano*
- **Tomate triturado**

![Lasaña boloñesa](https://upload.wikimedia.org/wikipedia/commons/0/0b/Lasagna_bolognese.jpg)
![Ingredientes lasaña](https://upload.wikimedia.org/wikipedia/commons/e/e8/Lasagna_ingredients.jpg)

---

## Preparación
1. Cocina la carne con tomate y especias.
2. Alterna capas de *pasta*, **salsa boloñesa** y *queso*.
3. Hornea durante 30 minutos a 180 °C.

---

## Consejos
- Deja reposar unos minutos antes de servir.
- Acompaña con una copa de **vino tinto italiano**.

Descubre más sobre la gastronomía de Italia en  
👉 [https://www.italia.it/es](https://www.italia.it/es)

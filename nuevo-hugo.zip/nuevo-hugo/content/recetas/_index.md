---
title: "Recetas Italianas"
---

# 🍝 Recetas Tradicionales de Italia

En esta sección comparto mis recetas favoritas de la *cocina italiana*,  
preparadas con ingredientes frescos y mucho **amor**.

Explora cómo preparar auténticos platos como la **pasta al pesto** y la *lasaña al horno*.

---

## Consejos generales
1. Usa siempre aceite de oliva extra virgen.
2. Cocina la pasta *al dente*.
3. Acompaña cada comida con un buen vino italiano.

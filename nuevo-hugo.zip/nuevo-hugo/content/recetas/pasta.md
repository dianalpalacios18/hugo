---
title: "Pasta al Pesto Genovese"
date: 2025-10-29
draft: false
---

# 🍃 Pasta al Pesto Genovese
Una receta clásica de **Génova**, ideal para los amantes de los sabores frescos.

## Ingredientes
- **Espaguetis o linguini**
- *Hojas de albahaca fresca*
- **Aceite de oliva virgen extra**
- *Queso parmesano rallado*
- **Piñones tostados**

![Pasta al pesto](https://upload.wikimedia.org/wikipedia/commons/a/a6/Pasta_al_pesto.jpg)
![Ingredientes frescos](https://upload.wikimedia.org/wikipedia/commons/7/7c/Pesto_ingredients.jpg)

---

## Preparación
1. Tritura la *albahaca* con los piñones, el queso y el aceite.
2. Cuece la pasta **al dente**.
3. Mezcla todo y sirve caliente.

---

## Tip del chef 👨‍🍳
Guarda un poco del agua de cocción de la pasta para que la salsa quede más cremosa.

Más recetas italianas en 👉 [Giallo Zafferano](https://www.giallozafferano.com/).

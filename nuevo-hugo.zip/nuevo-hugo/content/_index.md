---
title: "Mi Sitio Hugo"
---

# Bienvenido a mi sitio

Explora nuestras secciones:

## Viajes
- [París](/viajes/paris/)
- [Roma](/viajes/roma/)

---

## Recetas Italianas
- [Pasta](/recetas/pasta/)
- [Lasaña](/recetas/lasagna/)

---

## Tecnología
- [Inteligencia Artificial](/tecnologia/inteligencia-artificial/)
- [Robots](/tecnologia/robots/)


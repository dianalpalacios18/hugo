+++
date = '2025-10-27T01:17:33+01:00'
draft = true
title = 'Pastas'
+++
